# Secret Translator 🎙️ 🕵‍♂️️ 🔊️
To run the project first clone or download the zip file
**You must have installed django3,python3,required modules from installition.txt file and npm in your machine
steps to run the project 
1) $cd secrettranslator
2) $npm install
3) $npm start

now go back to parent directory
1) $cd stbackend
2) $python3 manage.py runserver

#finally you can see the index page

![Screenshot from 2022-09-19 16-08-50](https://user-images.githubusercontent.com/66793837/191001193-62122aef-3bcb-41f4-9af5-59d9831ecb22.png)

Then click on Get Started you will go to login page as follows
![Screenshot from 2022-09-19 16-08-55](https://user-images.githubusercontent.com/66793837/191001894-b3984641-85a5-4f71-9634-29d551ad7d5e.png)

Then provide username=test and password = test
you will redirected to selector page as follows
case 1:->

![Screenshot from 2022-09-19 16-09-09](https://user-images.githubusercontent.com/66793837/191002095-25eada7f-259a-4c72-ade1-32b557e4e307.png)

Now if your criminal is currently available and you want to take conversation with him then select GO WITH MIC and you will redirected to speech page
with provided 106 languages

![Screenshot from 2022-09-19 16-09-34](https://user-images.githubusercontent.com/66793837/191003006-e794b654-93b0-49e6-9e61-ddbce89de457.png)

If you're police select police else select criminal and appropriate input and output language and speak in mic .

![Screenshot from 2022-09-19 16-10-26](https://user-images.githubusercontent.com/66793837/191003465-2fb83116-27fe-4c95-b8d0-5709b111957f.png)

same for criminal

![Screenshot from 2022-09-19 16-12-42](https://user-images.githubusercontent.com/66793837/191003587-3a1f0f43-da08-4885-ab82-8c258cf91e62.png)

case 2 :->

If criminal got bail but you have his statement in another language then upload it and see the resulrt

for example the demo is as follows (upload .mp3 or .wav file)

i/p--> English
o/p--> Marathi

![Screenshot from 2022-09-19 16-15-08](https://user-images.githubusercontent.com/66793837/191004121-7f84a663-02d5-4cec-8767-2490626c068f.png)


i/p--> English
o/p--> Telugu

![Screenshot from 2022-09-19 16-15-29](https://user-images.githubusercontent.com/66793837/191004314-d3f68304-735d-40b2-b187-9acfc046c1b5.png)


If you want the statement with you then just click on Export file and boom.
The file is successfully download in your local machine.

![Screenshot from 2022-09-19 16-38-50](https://user-images.githubusercontent.com/66793837/191005074-9797e337-50dd-44bc-8d43-09b7a35a2053.png)

The final 404 page is 😅️
![Screenshot from 2022-09-19 16-42-34](https://user-images.githubusercontent.com/66793837/191005331-425bfcf6-60e4-4301-a6ae-721e6bba09f9.png)

Thank You 🤗️🤗️ 

